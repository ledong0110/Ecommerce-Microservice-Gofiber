package cross

type Cross struct {
	Array  []string
	String string
}
