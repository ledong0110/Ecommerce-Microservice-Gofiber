# swaggerFiles

[![Build Status](https://github.com/swaggo/files/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/features/actions)
[![Go Report Card](https://goreportcard.com/badge/github.com/swaggo/files)](https://goreportcard.com/report/github.com/swaggo/files)

Generate swagger ui embedded files by using:
```
	make
```